Uso: ./ip_bin "numero aquí sin comillas"

PD: Si vas a añadir mas de un numero, separalo con espacios
